Controls explained in game.

Everything in the game (programming, art, audio) is made by me, Patrick Yoder.